package com.ohgiraffers.parameterized.section01.params;

public class Calculator {
    public static int sumTwoNumbers(int num1, int num2) {

        return num1 + num2;
    }
}
