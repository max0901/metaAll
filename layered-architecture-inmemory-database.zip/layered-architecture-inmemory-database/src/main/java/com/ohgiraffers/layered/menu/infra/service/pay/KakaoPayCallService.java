package com.ohgiraffers.layered.menu.infra.service.pay;

import com.ohgiraffers.layered.menu.domain.service.pay.PayApiCallService;
import com.ohgiraffers.layered.menu.domain.service.pay.PayInfo;
import com.ohgiraffers.layered.menu.domain.service.pay.PayResult;

public class KakaoPayCallService implements PayApiCallService {
    @Override
    public PayResult pay(PayInfo pay) {
        return null;
    }
}
