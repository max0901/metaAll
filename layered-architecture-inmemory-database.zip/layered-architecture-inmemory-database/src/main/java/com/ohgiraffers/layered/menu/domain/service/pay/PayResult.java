package com.ohgiraffers.layered.menu.domain.service.pay;

public class PayResult {
}
