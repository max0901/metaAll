package com.ohgiraffers.layered.menu.domain.aggregate.enumtype;

public enum OrderableStatus {

    Y, N
}
