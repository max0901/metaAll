package com.ohgiraffers.assertions.section01.jupiter;

public class Calculator {

    public int plusTwoNumbers(int firstNum, int secondNum) {

        return firstNum + secondNum;
    }
}
