package com.ohgiraffers.parameterized.section01.params;

public class NumberValidator {
    public static boolean isOdd(int number) {

        return number % 2 != 0;
    }
}
