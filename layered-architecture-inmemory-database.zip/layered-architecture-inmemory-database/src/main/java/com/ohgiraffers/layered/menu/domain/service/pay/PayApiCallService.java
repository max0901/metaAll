package com.ohgiraffers.layered.menu.domain.service.pay;

public interface PayApiCallService {

    PayResult pay(PayInfo pay);
}
