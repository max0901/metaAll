package com.ohgiraffers.layered.database;

import com.ohgiraffers.layered.menu.domain.aggregate.entity.Category;

import java.util.Map;

public class CategoryInmemoryDatabase {

    private Map<Integer, Category> categoryMap;
}
