package com.ohgiraffers.layered.menu.application.service;

public class FindAllMenuService {
}
